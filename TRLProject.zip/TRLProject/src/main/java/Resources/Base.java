package Resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Base {

	//Define the driver variable at global level so that it can be re-used
	public static WebDriver driver;
	
	//Define the data properties variable at global level so that it can be re-used
	public Properties prop;
	
	public WebDriver initializeDriver() throws IOException
	{
	
		//Pre-req create a data driven property file and provide its path
		prop = new  Properties();
		FileInputStream fil= new FileInputStream("//Users//rush-ket//TRLProject//src//main//java//Resources//data.properties");
		
		prop.load(fil);
		String browserName = prop.getProperty("browser");
		
		if (browserName.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "//Users//rush-ket//Downloads//chromedriver");
			
			//To hit a URL on a browser
			driver=new ChromeDriver();
			
		}
		else if (browserName.equals("firefox"))
		{	
		//Firefox
		}
		else if (browserName.equals("IE"))
		{
		//IE
		}
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		return driver;
		
		
	}
	
	
	public void getScreenShot(String testCaseName,WebDriver driver) throws IOException
	{
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destinationFile = System.getProperty("//Users//rush-ket//TRLProject")+"//reports//"+testCaseName+".png";
	
		FileUtils.copyFile(source,new File(destinationFile));
		
	}
}
