package Resources;

import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;

public class JsonData {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		JSONObject jsono= new JSONObject();
		jsono.put("Make","land-rover");
		jsono.put("Model","discovery-sport");
		
		FileWriter file= new FileWriter("//Users//rush-ket//TRLProject//src//main//java//Resources//data.json");
		file.write(jsono.toJSONString());
		file.close();		

	}

}
