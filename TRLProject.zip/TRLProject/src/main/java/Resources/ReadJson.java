package Resources;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadJson {
	
	public String jsonmodel;
	public String jsonmake;

	
//public static void main(String[] args) throws IOException, ParseException {
//Methods
	
	
public String getJsonMake () throws FileNotFoundException, IOException, ParseException
{
	JSONParser jsonParser = new JSONParser();
	JSONObject jsonObject = (JSONObject) jsonParser.parse(new FileReader("/Users/rush-ket/TRLProject/src/main/java/Resources/data.json"));
	
	return (String)jsonObject.get("Make");
	//System.out.println(jsonObject.get("Make"));
}

public String getJsonModel () throws FileNotFoundException, IOException, ParseException
{
	JSONParser jsonParser = new JSONParser();
	JSONObject jsonObject = (JSONObject) jsonParser.parse(new FileReader("/Users/rush-ket/TRLProject/src/main/java/Resources/data.json"));
	
	return (String)jsonObject.get("Model");
	//System.out.println(jsonObject.get("Model"));
}
	
}
