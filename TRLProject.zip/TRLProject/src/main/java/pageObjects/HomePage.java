package pageObjects;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Resources.ReadJson;

public class HomePage {

public WebDriver driver;

	//Object definition Section	

	
	By homePage=By.xpath("//a[text() = 'Home']");
	By Make=By.xpath("//a[text()='Make']"); 	
	By Model=By.xpath("//a[text()='Model']");
	By search=By.cssSelector("button[type='submit']");
	
	
	//Create a constructor 
		public HomePage(WebDriver driver) {
			
			//Give life to the variable driver
			this.driver=driver;
		}
	
	//Methods Section

		
	public WebElement gotoHomePage() {
			
			return driver.findElement(homePage);
		}
	
	
	public WebElement clickonMake() {
		
		return driver.findElement(Make);
	}
	
	
	public WebElement ReadJsonDataMake() throws FileNotFoundException, IOException, ParseException {
		
		ReadJson rjmake = new ReadJson();
		String jsonmake = rjmake.getJsonMake();
		
		return driver.findElement(By.xpath("//a[@data-value='"+ jsonmake +"']"));
			
	}
	
	
	public WebElement clickonModel() {
		
		return driver.findElement(Model);
	}


	public WebElement ReadJsonDataModel() throws FileNotFoundException, IOException, ParseException {
		
		ReadJson rjmodel = new ReadJson();
		String jsonmodel = rjmodel.getJsonModel();
		
		return driver.findElement(By.xpath("//a[@data-value='"+ jsonmodel +"']"));
		
	}
	
	public WebElement clikOnSearch() {
		
		return driver.findElement(search);
	}
	

}

