package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class landingPage {

	//Object definition Section
	
	public WebDriver driver;
	
	//Web element - login is located on the Landing page and stored in below given variable -
	
	By login=By.cssSelector("a[href*='login']");
	
	
	
	//Create a constructor 
		public landingPage(WebDriver driver) {
			
			//Give life to the variable driver
			this.driver=driver;
		}
	
	
	//Methods Section
	
	//This method returns the location of Login on Landing page
		
	public WebElement getLogin() {
			
			return driver.findElement(login);
		}

}
