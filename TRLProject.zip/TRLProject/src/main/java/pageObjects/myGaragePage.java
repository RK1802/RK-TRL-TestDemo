package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class myGaragePage {

	//Object definition Section
	public WebDriver driver;

	
	By mygarage=By.cssSelector("a[class='my-garage-button']");
	
	
	//Create a constructor 
		public myGaragePage(WebDriver driver) {
			
			//Give life to the variable driver
			this.driver=driver;
		}
		
	//Methods Section
	
	public WebElement gotoMyGarage() {
			
			return driver.findElement(mygarage);
		
		}
	
	public static void RemoveItems(WebDriver driver,String[] itemsRemoved, String[]itemsNeeded) throws InterruptedException
	{
		
		for (int i = 0; i < itemsRemoved.length; i++) 
		{

			for (int k = 0; k < itemsNeeded.length; k++)
			{	
				
				By carref=By.xpath("//span[text()=" + itemsRemoved[i] + "']");
							
				if (carref.toString().contains(itemsRemoved[i]))
				{
				
					// Remove from the list
					System.out.println("true");
					driver.findElement(By.xpath("//*[@id=\"whatchlist_slider\"]/div/div/div/div[1]/p/a/span")).click();
					break;
				}
				
				//Slide to next page
				driver.findElement(By.cssSelector("span[class='watch-next slick-arrow']")).click();	
				
			}
				
		}
	
	}
}
	

