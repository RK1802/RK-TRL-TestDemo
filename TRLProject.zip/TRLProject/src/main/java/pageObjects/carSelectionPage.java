package pageObjects;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Resources.Base;

public class carSelectionPage extends Base {

	
	
	//Object definition Section
	
	public WebDriver driver;
	
	//Create a constructor 
		public carSelectionPage(WebDriver driver) {
			
			//Give life to the variable driver
			this.driver=driver;
		}

		
	//Methods Section

		public void SortItems() {
			
			
			driver.findElement(By.xpath("/html/body/section[1]/section[3]/div/div/div/div/div[1]/div[1]/div/div[3]/span/div/a")).click();
			
			driver.findElement(By.xpath("/html/body/section[1]/section[3]/div/div/div/div/div[1]/div[1]/div/div[3]/span/div/div/div/a[4]")).click();
			
			driver.findElement(By.xpath("/html/body/section[1]/section[3]/div/div/div/div/div[1]/div[1]/div/div[3]/span/div/a")).click();
				

		}
		
		public static void addItems(WebDriver driver,String[] itemsNeeded) throws InterruptedException
		{
			
		List itemsNeededList = Arrays.asList(itemsNeeded);
		
		
		List <WebElement> listofcars = driver.findElements(By.cssSelector("li[class='search-results__item']"));
		
		
		int carCount = 0;
	
		for (int i = 0; i < itemsNeededList.size(); i++)
		{
			String vehicleID= (String) itemsNeededList.get(i);
			
			
			for (int k = carCount; k < listofcars.size(); k++)
			{
				
			WebElement varxpath = listofcars.get(k).findElement(By.cssSelector("a[class*='hidden--small'][data-apiurl*='"+vehicleID+"'][data-category*='Buttons'][data-action*='Add to Watchlist']"));
		
			carCount ++;
			
			if (varxpath.toString().contains(vehicleID))
				{	
					
					listofcars.get(k).findElement(By.xpath("//a[text()='Add to watchlist']")).click();
					
					WebDriverWait w = new WebDriverWait(driver,2000);
					break;
						
				}
			
			}
			
		}	
		
	}
}
			
