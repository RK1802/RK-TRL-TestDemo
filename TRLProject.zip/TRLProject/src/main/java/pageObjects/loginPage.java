package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class loginPage {

	//Object definition Section
	
	public WebDriver driver;
	
	//Below variables store the location of Web elements - email, password & sign-In button on Login page -
	
	By email=By.cssSelector("[id='PartialLogin_Username']");
	By passw=By.cssSelector("[id='PartialLogin_Password']");
	By signIn=By.cssSelector("input[class='btn btn-blue']");
	
	
	//Create a constructor 
		public loginPage(WebDriver driver) {
			
			//Give life to the variable driver
			this.driver=driver;
		}
	
	
	//Methods Section
		
	//This method returns the location of email text box on Login page
		
	public WebElement getEmail() {
			
			return driver.findElement(email);
		}
	
	//This method returns the location of password text box on Login page
	public WebElement getPass() {
		
		return driver.findElement(passw);
	}
	
	//This method returns the location of SignIn button on Login page
	public WebElement signIn() {
		
		return driver.findElement(signIn);
	}

}
