package WishList;

import org.testng.annotations.Test;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import Resources.Base;
import pageObjects.myGaragePage;

//This test is to validate remove from watch list functionality

public class testCase4RemoveFromWatchList extends Base {
	
	public static Logger log=LogManager.getLogger(Base.class.getName());

	
	@Test
	public void RemoveItem() throws IOException, InterruptedException, ParseException
	{	
		
		//To remove item naviagte to Garage
		//Make sure that item is added for it to be removed. Run the addItem program before running itemRemoved
		
		myGaragePage gp = new myGaragePage (driver);
		gp.gotoMyGarage().click();
		
		//Below is the input string array to give the reference of the car to be removed
				//Please note it take items removed & items needed so make sure both the arrays are popualated before running this test
		
		String itemsNeeded[] = { "vehicleId=1008702"};
				
		//For your info - CE65BZD - 1008702, BT65DBZ - 1009009, SA16CVJ - 1010888, KC16HZD - 1010494, PX66PUU - 996098
		
		String itemsRemoved[] = { "CE65BZD" };
		
		gp.RemoveItems(driver, itemsRemoved, itemsNeeded );
		
		log.info("User has removed the car from the WatchList");
			
		
	}
	
	
}
