package WishList;

import org.testng.annotations.Test;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import Resources.Base;
import pageObjects.carSelectionPage;

//This test is to validate add to watch list functionality

public class testCase3AddToWatchList extends Base {
	
	public static Logger log=LogManager.getLogger(Base.class.getName());
	
	
	@Test
	public void AddItem() throws IOException, InterruptedException, ParseException
	{	

		//Below is the input string array to give the references of the cars to be added
		
		String itemsNeeded[] = { "vehicleId=1008702" };
				
		//FYI - CE65BZD - 1008702, BT65DBZ - 1009009, SA16CVJ - 1010888, KC16HZD - 1010494, PX66PUU - 996098
			
		carSelectionPage cp = new carSelectionPage (driver);
		cp.addItems(driver, itemsNeeded);
		
		log.info("Car(s) has added to WatchList");
			
		
	}
	
	
}
