package WishList;

import org.testng.annotations.Test;


import java.io.FileInputStream;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import Resources.Base;
import pageObjects.HomePage;
import pageObjects.carSelectionPage;
import pageObjects.landingPage;
import pageObjects.loginPage;
import pageObjects.myGaragePage;

//This class is to run the full test from start to end

public class fullTest extends Base {
	
	public static Logger log=LogManager.getLogger(Base.class.getName());
	
	@BeforeTest
	public void Initialize() throws IOException
	{
		driver=initializeDriver(); //this method is returning driver
		
	}
	
	@Test
	public void EntireTest() throws IOException, InterruptedException, ParseException
	{	
		
		//Landing Page
		
		driver.get(prop.getProperty("url"));
		landingPage l=new landingPage(driver);
		l.getLogin().click();
		
		//Get Username and Password data from data properties file
		
		FileInputStream fil= new FileInputStream("//Users//rush-ket//TRLProject//src//main//java//Resources//data.properties");
		
		prop.load(fil);
		String username = prop.getProperty("usern");
		String password = prop.getProperty("passw");
		
		//Loging Page
		
		loginPage lp=new loginPage(driver);
		lp.getEmail().sendKeys(username);
		lp.getPass().sendKeys(password);
		lp.signIn().click();	
		
		log.info("User has logged in");
		
		HomePage hp=new HomePage(driver);
		hp.gotoHomePage().click();
		
		//To close the popup
		WebDriverWait w = new WebDriverWait(driver,2000);
		driver.findElement(By.cssSelector("button[class*='CloseButton']")).click();
		
		log.info("User is on Home Page");
		
		//Data is read from the json file data.json for make and model selection methods
		
		hp.clickonMake().click();
		hp.ReadJsonDataMake().click();
		
		
		hp.clickonModel().click();
		hp.ReadJsonDataModel().click();
		
		hp.clikOnSearch().click();
		
		log.info("User has selected Make and Model");
		
		//Below is the input string array to give the references of the cars to be added
		
		String itemsNeeded[] = { "vehicleId=1008702" };
		
		//CE65BZD - 1008702, BT65DBZ - 1009009, SA16CVJ - 1010888, KC16HZD - 1010494, PX66PUU - 996098
		
		carSelectionPage cp = new carSelectionPage (driver);
		cp.addItems(driver, itemsNeeded);
		
		log.info("User has added to WatchList");
		
		//To remove item naviagte to Garage
		//Make sure that item is added for it to be removed. Run the addItem program before running itemRemoved
		
		myGaragePage gp = new myGaragePage (driver);
		gp.gotoMyGarage().click();
		
		//Below is the input string array to give the reference of the car to be removed
		//Please note it take items removed & items needed so make sure both the arrays are popualated before running this test
		
		String itemsRemoved[] = { "CE65BZD" };
		
		gp.RemoveItems(driver, itemsRemoved, itemsNeeded );
		log.info("User has removed from WatchList");
		
		//Below test is to sort.
		//Steps covered are - go to home page, select make & model and then sort -
		
		hp.gotoHomePage().click();

		hp.clickonMake().click();
		hp.ReadJsonDataMake().click();
		
		
		hp.clickonModel().click();
		hp.ReadJsonDataModel().click();
		
		hp.clikOnSearch().click();
		cp.SortItems();		
		
	}
	
	
}
