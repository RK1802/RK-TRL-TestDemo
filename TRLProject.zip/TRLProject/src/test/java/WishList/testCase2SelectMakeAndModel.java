package WishList;

import org.testng.annotations.Test;

import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import Resources.Base;
import pageObjects.HomePage;

//This test is to validate the select make and model functionality

public class testCase2SelectMakeAndModel extends Base {
	
	public static Logger log=LogManager.getLogger(Base.class.getName());
	
	
	@Test
	public void SelectMakeandModel() throws IOException, InterruptedException, ParseException
	{	
		
		//Data is read from the json file data.json for make and model selection methods
		
		HomePage hp=new HomePage(driver);
		
		Thread.sleep(2000L);
		
		hp.clickonMake().click();
		hp.ReadJsonDataMake().click();
		
		Thread.sleep(2000L);
		
		hp.clickonModel().click();
		hp.ReadJsonDataModel().click();
		
		hp.clikOnSearch().click();
		
		log.info("User has selected Make and Model");	
		
	}
	
	
}
