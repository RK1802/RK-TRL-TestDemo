package WishList;

import org.testng.annotations.Test;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import Resources.Base;
import pageObjects.HomePage;
import pageObjects.carSelectionPage;

//This test is to validate sorting functionality

public class testCase5SortCarList extends Base {
	
	public static Logger log=LogManager.getLogger(Base.class.getName());
	
	
	@Test
	public void Sorting() throws IOException, InterruptedException, ParseException
	{	
		
		//Below test is to sort.
		//Steps covered are - go to home page, select make & model and then sort -
		
		HomePage hp=new HomePage(driver);
		hp.gotoHomePage().click();
		
		Thread.sleep(2000L);
		
		hp.clickonMake().click();
		hp.ReadJsonDataMake().click();
		
		Thread.sleep(2000L);
		
		hp.clickonModel().click();
		hp.ReadJsonDataModel().click();
		
		hp.clikOnSearch().click();
		
		log.info("User has selected Make and Model for sorting");
		
		carSelectionPage cp = new carSelectionPage (driver);
		cp.SortItems();
		
		log.info("List of cars are sorted");
		log.info("End of Program");		
		
	}
	
	@AfterTest
	public void teardown() //To close all the browsers
	{
		driver.close();
		driver=null;
		
		log.info("Browser is closed");	
	}
}
