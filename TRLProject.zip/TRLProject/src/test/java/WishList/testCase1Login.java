package WishList;

import org.testng.annotations.Test;
import java.io.FileInputStream;
import java.io.IOException;

import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import Resources.Base;
import pageObjects.HomePage;
import pageObjects.landingPage;
import pageObjects.loginPage;

//This test is to validate the login functionality

public class testCase1Login extends Base {
	
	public static Logger log=LogManager.getLogger(Base.class.getName());
	
	@BeforeTest
	public void Initialize() throws IOException
	{
		driver=initializeDriver(); //this method is returning driver
		
	}
	
	@Test
	public void login() throws IOException, InterruptedException, ParseException
	{	
		
		//Landing Page
		
		driver.get(prop.getProperty("url"));
		landingPage l=new landingPage(driver);
		l.getLogin().click();
		
		//Get Username and Password data from data properties file
		
		FileInputStream fil= new FileInputStream("//Users//rush-ket//TRLProject//src//main//java//Resources//data.properties");
		
		prop.load(fil);
		String username = prop.getProperty("usern");
		String password = prop.getProperty("passw");
		
		//Loging Page
		
		loginPage lp=new loginPage(driver);
		lp.getEmail().sendKeys(username);
		lp.getPass().sendKeys(password);
		lp.signIn().click();	
		
		log.info("User has logged in");
		
		HomePage hp=new HomePage(driver);
		hp.gotoHomePage().click();
		
		//To close the popup
		
		WebDriverWait w = new WebDriverWait(driver,1000);
		driver.findElement(By.cssSelector("button[class*='CloseButton']")).click();
		
		log.info("User is on Home Page");
		
	}
	
	
}
